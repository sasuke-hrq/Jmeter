/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "/zentao/bug-edit-5.html-19-0"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/story-ajaxGetProductStories-1-0-0-null.html-22"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-edit-5.html-19-1"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1-0-byModule-0-id_desc.html-18-1"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1-0-byModule-0-id_desc.html-18-0"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1.html-9-1"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/theme/zui/fonts/Oswald-Regular.ttf-8"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1.html-9-0"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-edit-5.html-19"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1.html-1"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/score-ajax-lastNext.html-23"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1.html-9"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-create-1-0-moduleID=0.html-17"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1-0-byModule-0-id_desc.html-18"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/js/kindeditor/kindeditor.min.js-11"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/theme/zui/fonts/ZentaoIcon.woff-4"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-create-1-0-moduleID=0.html-10"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1.html-1-1"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-browse-1.html-1-0"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-edit-5.html-24-1"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/theme/zui/fonts/ZentaoIcon.ttf-7"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/index-index.html-6"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-edit-5.html-24-0"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-ajaxGetModuleOwner-0-1.html-16"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-create-1-0-moduleID=0.html-17-0"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-create-1-0-moduleID=0.html-10-0"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-create-1-0-moduleID=0.html-10-1"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/js/kindeditor/kindeditor.min.js-20"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/js/all.js-3"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-edit-5.html-24"], "isController": false}, {"data": [1.0, 500, 1500, "/zentao/bug-create-1-0-moduleID=0.html-17-1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1550, 0, 0.0, 53.08064516129033, 0, 272, 44.0, 106.0, 128.89999999999964, 177.49, 142.6336615441244, 2582.228233988221, 138.90174956289684], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["/zentao/bug-edit-5.html-19-0", 50, 0, 0.0, 42.07999999999999, 11, 112, 39.5, 77.49999999999997, 102.69999999999997, 112.0, 5.005005005005005, 5.997208145645645, 2.3998607982982985], "isController": false}, {"data": ["/zentao/story-ajaxGetProductStories-1-0-0-null.html-22", 50, 0, 0.0, 49.040000000000006, 11, 116, 45.5, 88.6, 101.89999999999999, 116.0, 5.02563071665494, 6.472953468941602, 2.051478163634536], "isController": false}, {"data": ["/zentao/bug-edit-5.html-19-1", 50, 0, 0.0, 44.780000000000015, 14, 105, 41.0, 78.69999999999999, 89.79999999999998, 105.0, 5.0115265109752425, 14.81924050315726, 2.5008691866292474], "isController": false}, {"data": ["/zentao/bug-browse-1-0-byModule-0-id_desc.html-18-1", 50, 0, 0.0, 45.699999999999996, 12, 97, 44.0, 83.6, 93.79999999999998, 97.0, 4.995004995004995, 14.770385864135864, 2.4536010864135864], "isController": false}, {"data": ["/zentao/bug-browse-1-0-byModule-0-id_desc.html-18-0", 50, 0, 0.0, 39.160000000000004, 11, 88, 36.0, 63.599999999999994, 66.0, 88.0, 4.9805757545572265, 6.123578979480028, 2.461104816216755], "isController": false}, {"data": ["/zentao/bug-browse-1.html-9-1", 50, 0, 0.0, 42.019999999999996, 12, 121, 37.5, 69.8, 80.94999999999996, 121.0, 4.876145894285157, 14.418439602837918, 2.328550138970158], "isController": false}, {"data": ["/zentao/theme/zui/fonts/Oswald-Regular.ttf-8", 50, 0, 0.0, 4.8999999999999995, 0, 22, 3.0, 10.899999999999999, 15.899999999999991, 22.0, 4.884720593982024, 407.124765686059, 2.199078314282923], "isController": false}, {"data": ["/zentao/bug-browse-1.html-9-0", 50, 0, 0.0, 40.37999999999998, 10, 88, 36.5, 79.19999999999999, 83.44999999999999, 88.0, 4.88328938372888, 5.869961818781131, 2.2461223630237326], "isController": false}, {"data": ["/zentao/bug-edit-5.html-19", 50, 0, 0.0, 86.97999999999999, 31, 170, 84.5, 144.9, 155.79999999999998, 170.0, 4.998000799680129, 20.768059963514595, 4.890621876249501], "isController": false}, {"data": ["/zentao/bug-browse-1.html-1", 50, 0, 0.0, 93.20000000000002, 35, 196, 87.0, 154.5, 178.59999999999997, 196.0, 4.849190185239065, 20.1672326580836, 4.252512486664727], "isController": false}, {"data": ["/zentao/score-ajax-lastNext.html-23", 50, 0, 0.0, 24.300000000000004, 7, 60, 18.0, 48.8, 56.89999999999999, 60.0, 5.048465266558966, 6.0487910503331985, 1.9671266028877221], "isController": false}, {"data": ["/zentao/bug-browse-1.html-9", 50, 0, 0.0, 82.52000000000001, 31, 186, 75.0, 127.6, 146.35, 186.0, 4.866180048661801, 20.238366788321166, 4.562043795620438], "isController": false}, {"data": ["/zentao/bug-create-1-0-moduleID=0.html-17", 50, 0, 0.0, 115.10000000000002, 39, 215, 105.0, 192.1, 199.35, 215.0, 4.88997555012225, 43.18364150366748, 19.410146699266505], "isController": false}, {"data": ["/zentao/bug-browse-1-0-byModule-0-id_desc.html-18", 50, 0, 0.0, 84.96000000000002, 23, 156, 80.5, 130.5, 145.45, 156.0, 4.970673029128144, 20.809839136594096, 4.897860435928025], "isController": false}, {"data": ["/zentao/js/kindeditor/kindeditor.min.js-11", 50, 0, 0.0, 32.95999999999999, 12, 85, 33.0, 50.0, 65.39999999999995, 85.0, 4.885197850512945, 292.5107627015144, 1.8796562042012703], "isController": false}, {"data": ["/zentao/theme/zui/fonts/ZentaoIcon.woff-4", 50, 0, 0.0, 6.480000000000002, 0, 31, 5.0, 15.799999999999997, 21.24999999999998, 31.0, 4.885197850512945, 302.3088284684905, 2.3185606985832927], "isController": false}, {"data": ["/zentao/bug-create-1-0-moduleID=0.html-10", 50, 0, 0.0, 76.78, 30, 139, 71.5, 115.9, 134.59999999999997, 139.0, 4.863340142009532, 20.286397541581557, 4.630621717245404], "isController": false}, {"data": ["/zentao/bug-browse-1.html-1-1", 50, 0, 0.0, 50.439999999999976, 13, 156, 42.5, 88.69999999999999, 106.44999999999999, 156.0, 4.913522012578616, 14.52847846648978, 2.1976494939072326], "isController": false}, {"data": ["/zentao/bug-browse-1.html-1-0", 50, 0, 0.0, 42.62000000000002, 16, 140, 33.0, 79.8, 99.64999999999992, 140.0, 4.870920603994155, 5.8550939174378955, 2.0929736970287385], "isController": false}, {"data": ["/zentao/bug-edit-5.html-24-1", 50, 0, 0.0, 44.120000000000005, 14, 93, 39.5, 70.9, 77.89999999999999, 93.0, 5.106209150326798, 15.098721373314952, 2.592996834150327], "isController": false}, {"data": ["/zentao/theme/zui/fonts/ZentaoIcon.ttf-7", 50, 0, 0.0, 3.9600000000000017, 0, 16, 2.5, 10.899999999999999, 12.349999999999987, 16.0, 4.88663017982799, 302.0128335125098, 2.2142543002345585], "isController": false}, {"data": ["/zentao/index-index.html-6", 50, 0, 0.0, 66.9, 15, 137, 64.5, 110.8, 120.69999999999997, 137.0, 4.858614323195025, 66.37892029443202, 2.2347727990477115], "isController": false}, {"data": ["/zentao/bug-edit-5.html-24-0", 50, 0, 0.0, 39.46, 12, 146, 33.0, 74.9, 87.79999999999998, 146.0, 5.066882853668424, 6.070857981607215, 19.243664813032023], "isController": false}, {"data": ["/zentao/bug-ajaxGetModuleOwner-0-1.html-16", 50, 0, 0.0, 52.17999999999998, 13, 108, 46.5, 89.0, 100.24999999999997, 108.0, 4.892367906066536, 5.93868487035225, 2.011412977005871], "isController": false}, {"data": ["/zentao/bug-create-1-0-moduleID=0.html-17-0", 50, 0, 0.0, 44.44000000000002, 13, 108, 43.0, 78.9, 88.04999999999995, 108.0, 4.902441415825081, 5.893462287969409, 17.142458819492106], "isController": false}, {"data": ["/zentao/bug-create-1-0-moduleID=0.html-10-0", 50, 0, 0.0, 34.16, 14, 71, 30.5, 60.9, 68.89999999999999, 71.0, 4.869971754163826, 5.912925665968638, 2.3065784187201714], "isController": false}, {"data": ["/zentao/bug-create-1-0-moduleID=0.html-10-1", 50, 0, 0.0, 42.44000000000001, 13, 93, 40.0, 72.6, 83.84999999999994, 93.0, 4.879000780640125, 14.42783424204723, 2.3346781079234975], "isController": false}, {"data": ["/zentao/js/kindeditor/kindeditor.min.js-20", 50, 0, 0.0, 40.959999999999994, 12, 111, 39.5, 71.1, 88.24999999999997, 111.0, 5.012028869286287, 300.1045282114575, 1.8550380287690456], "isController": false}, {"data": ["/zentao/js/all.js-3", 50, 0, 0.0, 118.15999999999998, 33, 272, 113.5, 195.89999999999998, 217.29999999999984, 272.0, 4.868549172346641, 727.547620496592, 1.83046038218111], "isController": false}, {"data": ["/zentao/bug-edit-5.html-24", 50, 0, 0.0, 83.72, 26, 178, 82.0, 139.89999999999998, 154.7, 178.0, 5.059704513256426, 21.023467541995547, 21.785783179012345], "isController": false}, {"data": ["/zentao/bug-create-1-0-moduleID=0.html-17-1", 50, 0, 0.0, 70.60000000000001, 19, 168, 67.5, 108.0, 137.89999999999992, 168.0, 4.934859849980261, 37.64758315238847, 2.3324923509672324], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1550, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
